@echo off
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
"%~dp0tools\python\python.exe" "%~dp0tools\app\make_shortcut.py"
