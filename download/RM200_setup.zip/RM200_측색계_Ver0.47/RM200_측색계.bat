@echo off
cd /d "%~dp0"
start "" "%~dp0tools\python\pythonw.exe" "%~dp0tools\app\run.py"
