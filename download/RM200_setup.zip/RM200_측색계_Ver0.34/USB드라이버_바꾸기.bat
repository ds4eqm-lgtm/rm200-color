@echo off
start "" "%~dp0tools\zadig\zadig-2.9.exe"
